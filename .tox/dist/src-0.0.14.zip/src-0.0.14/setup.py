from setuptools import setup, find_packages

setup(
    name="src",
    version ="0.0.14",
    description ="this is a Thyroid detection engine",
    author = "codeGenius",
    packages = find_packages(),
    license = "MIT"
)